# ⚔️ PvP Practice Bot Mod — Fabric 1.21.11

A Fabric mod for Minecraft 1.21.11 that spawns intelligent PvP practice bots
you can command to attack specific players.

---

## 📦 Requirements

| Software | Version |
|---|---|
| Java JDK | 21 |
| Minecraft | 1.21.11 |
| Fabric Loader | 0.16.14+ |
| Fabric API | 0.140.2+1.21.11 |

---

## 🔨 How to Build

> You need Java 21 and Git installed.

1. **Clone / download** this folder somewhere on your PC.
2. Open a terminal inside the `pvpbot-mod` folder.
3. Run:
   ```bash
   # On Windows
   gradlew.bat build

   # On Linux / Mac
   ./gradlew build
   ```
4. The compiled `.jar` will be in `build/libs/pvpbot-1.0.0.jar`.
5. Drop that `.jar` into your Minecraft `mods/` folder alongside `fabric-api`.

> First build may take a few minutes — Gradle will download Minecraft + Fabric automatically.

---

## 🎮 In-Game Commands

All commands require **OP level 2** (`/op yourname`).

| Command | Description |
|---|---|
| `/pvpbot spawn <n>` | Spawns a bot at your feet with the given name |
| `/pvpbot attack <botName> <player>` | Orders the bot to attack a specific player |
| `/pvpbot stop <botName>` | Makes the bot go passive / stop attacking |
| `/pvpbot remove <botName>` | Removes the bot from the world |
| `/pvpbot list` | Lists all active bots and their targets |

### Example Usage

```
/pvpbot spawn Alpha
/pvpbot attack Alpha LostGalaxy6
/pvpbot stop Alpha
/pvpbot remove Alpha
```

When you run `/pvpbot attack Alpha LostGalaxy6`:
- Bot **Alpha** will sprint toward and attack **LostGalaxy6**
- **LostGalaxy6** receives a chat message: `⚔ PvP bot Alpha is targeting you!`

---

## 🤖 Bot Behavior

- Wears full **Iron Armor** and carries an **Iron Sword**
- Navigates around obstacles using Minecraft's built-in pathfinding
- Will not despawn naturally (survives chunk reloads during the session)
- Custom name tag visible: `[PvP Bot] <n>`
- Re-engages target if they run away (follow range: 32 blocks)

---

## 📁 Project Structure

```
pvpbot-mod/
├── build.gradle
├── gradle.properties        ← Change versions here if needed
├── settings.gradle
└── src/main/
    ├── java/com/pvpbot/
    │   ├── PvpBotMod.java          ← Mod entry point
    │   ├── PvpBotEntity.java       ← The bot AI entity
    │   ├── PvpBotEntities.java     ← Entity type registration
    │   ├── PvpBotCommands.java     ← All /pvpbot commands
    │   └── PvpBotDataGenerator.java
    └── resources/
        ├── fabric.mod.json
        └── pvpbot.mixins.json
```

---

## ❓ Troubleshooting

**Bot won't attack?**
- Make sure the target player is within 32 blocks when you issue the command.
- Make sure you used `/pvpbot spawn` first before `/pvpbot attack`.

**"No bot found" error?**
- Bot names are **case-insensitive** but must match. Use `/pvpbot list` to check exact names.

**Build fails?**
- Make sure you have **Java 21** installed (`java -version` in terminal).
- Try `gradlew clean build` to force a fresh build.
