package com.pvpbot;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class PvpBotEntities {

    /**
     * The EntityType for our PvP bot.
     * Registered under the id "pvpbot:pvp_bot".
     */
    public static final EntityType<PvpBotEntity> PVP_BOT =
            Registry.register(
                    Registries.ENTITY_TYPE,
                    Identifier.of(PvpBotMod.MOD_ID, "pvp_bot"),
                    EntityType.Builder.<PvpBotEntity>create(PvpBotEntity::new, SpawnGroup.MISC)
                            .dimensions(0.6f, 1.8f)   // same size as a player
                            .maxTrackingRange(64)
                            .build()
            );

    /**
     * Call this from PvpBotMod.onInitialize() so the class is loaded
     * and the static field above is evaluated (triggering registration).
     */
    public static void register() {
        // Register default attributes for our entity type
        net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry
                .register(PVP_BOT, PvpBotEntity.createAttributes());

        PvpBotMod.LOGGER.info("PvP Bot entity type registered.");
    }
}
