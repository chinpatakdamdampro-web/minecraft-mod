package com.pvpbot;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.UUID;

/**
 * PvpBotEntity - A custom mob that acts as a PvP practice partner.
 *
 * It behaves like a regular PathAwareEntity (walks around, navigates)
 * but targets a specific player via /pvpbot attack <botName> <playerName>.
 *
 * Goals registered (in priority order):
 *  1. SwimGoal          – doesn't drown
 *  2. MeleeAttackGoal   – attacks its target
 *  3. WanderAroundGoal  – wanders when idle
 *  4. LookAtEntityGoal  – looks at nearby players
 *  5. LookAroundGoal    – random head movement
 */
public class PvpBotEntity extends PathAwareEntity {

    /** The UUID of the player this bot should attack. Null = passive. */
    private UUID targetPlayerUUID = null;

    /** Human-readable name of this bot (set on spawn). */
    private String botLabel = "PvPBot";

    // -----------------------------------------------------------------------
    //  Constructor
    // -----------------------------------------------------------------------

    public PvpBotEntity(EntityType<? extends PathAwareEntity> entityType, World world) {
        super(entityType, world);
        this.setCustomNameVisible(true);
        this.setCustomName(Text.literal("§c[PvP Bot] §f" + botLabel));
    }

    // -----------------------------------------------------------------------
    //  Attribute defaults (called once during entity registration)
    // -----------------------------------------------------------------------

    public static DefaultAttributeContainer.Builder createAttributes() {
        return PathAwareEntity.createMobAttributes()
                .add(EntityAttributes.MAX_HEALTH, 20.0)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.ATTACK_DAMAGE, 3.0)
                .add(EntityAttributes.FOLLOW_RANGE, 32.0)
                .add(EntityAttributes.ARMOR, 4.0);
    }

    // -----------------------------------------------------------------------
    //  Goal registration
    // -----------------------------------------------------------------------

    @Override
    protected void initGoals() {
        // Survival
        this.goalSelector.add(0, new SwimGoal(this));

        // Attack target
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.2, true));

        // Movement when idle
        this.goalSelector.add(4, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(6, new LookAroundGoal(this));

        // Target selector – only attacks the assigned player
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true,
                entity -> {
                    if (targetPlayerUUID == null) return false;
                    return entity.getUuid().equals(targetPlayerUUID);
                }));
    }

    // -----------------------------------------------------------------------
    //  Equipment – give bot a sword so it looks the part
    // -----------------------------------------------------------------------

    @Override
    protected void initEquipment(net.minecraft.util.math.random.Random random,
                                  net.minecraft.world.LocalDifficulty difficulty) {
        this.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
        this.equipStack(EquipmentSlot.HEAD,     new ItemStack(Items.IRON_HELMET));
        this.equipStack(EquipmentSlot.CHEST,    new ItemStack(Items.IRON_CHESTPLATE));
        this.equipStack(EquipmentSlot.LEGS,     new ItemStack(Items.IRON_LEGGINGS));
        this.equipStack(EquipmentSlot.FEET,     new ItemStack(Items.IRON_BOOTS));
    }

    // -----------------------------------------------------------------------
    //  Public API used by commands
    // -----------------------------------------------------------------------

    /**
     * Assign the bot a new target player.
     * If targetUUID is null the bot becomes passive again.
     */
    public void setTargetPlayer(UUID targetUUID) {
        this.targetPlayerUUID = targetUUID;

        // Force goal system to re-evaluate immediately
        this.setTarget(null);

        if (targetUUID != null && this.getWorld() instanceof ServerWorld serverWorld) {
            PlayerEntity player = serverWorld.getPlayerByUuid(targetUUID);
            if (player != null) {
                this.setTarget(player);
            }
        }
    }

    /** Returns the UUID of the current target, or null if passive. */
    public UUID getTargetPlayerUUID() {
        return targetPlayerUUID;
    }

    /** Update the display label (shown in custom name tag). */
    public void setBotLabel(String label) {
        this.botLabel = label;
        this.setCustomName(Text.literal("§c[PvP Bot] §f" + label));
    }

    public String getBotLabel() {
        return botLabel;
    }

    // -----------------------------------------------------------------------
    //  Prevent the bot from despawning naturally
    // -----------------------------------------------------------------------

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    protected boolean isDisallowedInPeaceful() {
        return false;
    }
}
