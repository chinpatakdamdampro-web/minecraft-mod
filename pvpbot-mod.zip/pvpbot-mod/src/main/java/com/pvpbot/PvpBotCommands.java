package com.pvpbot;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.Entity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Registers all /pvpbot commands:
 *
 *   /pvpbot spawn <name>             – Spawns a new PvP bot at your location
 *   /pvpbot attack <botName> <player>– Orders the named bot to attack a player
 *   /pvpbot stop <botName>           – Makes the named bot go passive
 *   /pvpbot remove <botName>         – Removes (kills) the named bot
 *   /pvpbot list                     – Lists all active bots
 *
 * NOTE: All commands require OP level 2.
 */
public class PvpBotCommands {

    /** In-memory list of spawned bots for this session. */
    private static final List<PvpBotEntity> activeBots = new ArrayList<>();

    public static void register() {
        // Register entity type first
        PvpBotEntities.register();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(
                        CommandManager.literal("pvpbot")
                                .requires(source -> source.hasPermissionLevel(2))

                                // ── /pvpbot spawn <name> ────────────────────────────
                                .then(CommandManager.literal("spawn")
                                        .then(CommandManager.argument("name", StringArgumentType.word())
                                                .executes(ctx -> spawnBot(ctx,
                                                        StringArgumentType.getString(ctx, "name")))))

                                // ── /pvpbot attack <botName> <player> ───────────────
                                .then(CommandManager.literal("attack")
                                        .then(CommandManager.argument("botName", StringArgumentType.word())
                                                .then(CommandManager.argument("player",
                                                        EntityArgumentType.player())
                                                        .executes(ctx -> attackPlayer(ctx,
                                                                StringArgumentType.getString(ctx, "botName"),
                                                                EntityArgumentType.getPlayer(ctx, "player"))))))

                                // ── /pvpbot stop <botName> ──────────────────────────
                                .then(CommandManager.literal("stop")
                                        .then(CommandManager.argument("botName", StringArgumentType.word())
                                                .executes(ctx -> stopBot(ctx,
                                                        StringArgumentType.getString(ctx, "botName")))))

                                // ── /pvpbot remove <botName> ────────────────────────
                                .then(CommandManager.literal("remove")
                                        .then(CommandManager.argument("botName", StringArgumentType.word())
                                                .executes(ctx -> removeBot(ctx,
                                                        StringArgumentType.getString(ctx, "botName")))))

                                // ── /pvpbot list ────────────────────────────────────
                                .then(CommandManager.literal("list")
                                        .executes(PvpBotCommands::listBots))
                ));
    }

    // =========================================================================
    //  Command implementations
    // =========================================================================

    /** Spawns a PvP bot at the command sender's current location. */
    private static int spawnBot(CommandContext<ServerCommandSource> ctx, String name) {
        ServerCommandSource source = ctx.getSource();

        try {
            ServerPlayerEntity caller = source.getPlayerOrThrow();
            ServerWorld world = caller.getServerWorld();

            PvpBotEntity bot = PvpBotEntities.PVP_BOT.create(world);
            if (bot == null) {
                source.sendError(Text.literal("§cFailed to create bot entity."));
                return 0;
            }

            bot.setBotLabel(name);
            bot.setPosition(caller.getX(), caller.getY(), caller.getZ());
            world.spawnEntity(bot);
            activeBots.add(bot);

            source.sendFeedback(() ->
                    Text.literal("§aSpawned PvP bot §e" + name + " §aat your location!"), true);
            return 1;

        } catch (Exception e) {
            source.sendError(Text.literal("§cYou must be a player to spawn a bot."));
            return 0;
        }
    }

    /**
     * Orders a named bot to continuously attack the specified player.
     * This is the key feature: /pvpbot attack <botName> <player>
     */
    private static int attackPlayer(CommandContext<ServerCommandSource> ctx,
                                    String botName,
                                    ServerPlayerEntity targetPlayer) {
        ServerCommandSource source = ctx.getSource();

        PvpBotEntity bot = findBotByName(botName);
        if (bot == null) {
            source.sendError(Text.literal("§cNo bot named §e" + botName + " §cwas found. " +
                    "Use §f/pvpbot list §cto see active bots."));
            return 0;
        }

        if (bot.isRemoved()) {
            activeBots.remove(bot);
            source.sendError(Text.literal("§cBot §e" + botName + " §cno longer exists."));
            return 0;
        }

        UUID playerUUID = targetPlayer.getUuid();
        bot.setTargetPlayer(playerUUID);

        source.sendFeedback(() ->
                Text.literal("§e" + botName + " §ais now targeting §c" +
                        targetPlayer.getName().getString() + "§a!"), true);

        // Also notify the targeted player
        targetPlayer.sendMessage(
                Text.literal("§c⚔ §ePvP bot §f" + botName + " §cis targeting you! Good luck!"),
                false);

        return 1;
    }

    /** Clears the bot's target so it wanders passively. */
    private static int stopBot(CommandContext<ServerCommandSource> ctx, String botName) {
        ServerCommandSource source = ctx.getSource();

        PvpBotEntity bot = findBotByName(botName);
        if (bot == null) {
            source.sendError(Text.literal("§cNo bot named §e" + botName + " §cwas found."));
            return 0;
        }

        bot.setTargetPlayer(null);
        source.sendFeedback(() ->
                Text.literal("§aBot §e" + botName + " §ais now passive."), true);
        return 1;
    }

    /** Removes (kills) a named bot from the world. */
    private static int removeBot(CommandContext<ServerCommandSource> ctx, String botName) {
        ServerCommandSource source = ctx.getSource();

        PvpBotEntity bot = findBotByName(botName);
        if (bot == null) {
            source.sendError(Text.literal("§cNo bot named §e" + botName + " §cwas found."));
            return 0;
        }

        bot.discard(); // removes entity from the world cleanly
        activeBots.remove(bot);

        source.sendFeedback(() ->
                Text.literal("§aRemoved bot §e" + botName + "§a."), true);
        return 1;
    }

    /** Lists all currently tracked bots and their status. */
    private static int listBots(CommandContext<ServerCommandSource> ctx) {
        ServerCommandSource source = ctx.getSource();

        // Clean up any bots that have been removed from the world
        activeBots.removeIf(Entity::isRemoved);

        if (activeBots.isEmpty()) {
            source.sendFeedback(() ->
                    Text.literal("§eNo active PvP bots. Spawn one with §f/pvpbot spawn <name>"), false);
            return 1;
        }

        StringBuilder sb = new StringBuilder("§6Active PvP Bots:\n");
        for (PvpBotEntity bot : activeBots) {
            UUID targetUUID = bot.getTargetPlayerUUID();
            String status;
            if (targetUUID == null) {
                status = "§7[Passive]";
            } else {
                // Try to resolve UUID to name
                ServerWorld world = (ServerWorld) bot.getWorld();
                ServerPlayerEntity target = (ServerPlayerEntity) world.getPlayerByUuid(targetUUID);
                status = "§cAttacking: " + (target != null ? target.getName().getString() : "§7[offline player]");
            }
            sb.append("  §e").append(bot.getBotLabel()).append(" §f- ").append(status).append("\n");
        }

        final String message = sb.toString().trim();
        source.sendFeedback(() -> Text.literal(message), false);
        return activeBots.size();
    }

    // =========================================================================
    //  Helper
    // =========================================================================

    /** Finds a bot by its label (case-insensitive). Returns null if not found. */
    private static PvpBotEntity findBotByName(String name) {
        activeBots.removeIf(Entity::isRemoved); // clean dead bots first
        for (PvpBotEntity bot : activeBots) {
            if (bot.getBotLabel().equalsIgnoreCase(name)) {
                return bot;
            }
        }
        return null;
    }
}
